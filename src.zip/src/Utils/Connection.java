/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utils;

/**
 *
 * @author Sentinail
 */
public class Connection {
    public static final String ENDPOINT = "jdbc:mysql://localhost:3306/mapua_real_estate";
    public static final String USER = "root";
    public static final String PASSWORD = "";
}
